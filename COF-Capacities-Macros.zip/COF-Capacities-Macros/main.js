import { Macros } = "../../systems/cof/module/system/macros".js



